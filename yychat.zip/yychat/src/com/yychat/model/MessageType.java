package com.yychat.model;

public interface MessageType {
	String message_LoginSuccess="1";//�ַ�������
	String message_LoginFailure="0";
	String message_Common="2";
}
